# Verification Evidence Index

Each phase has its own proof report matching the corresponding git tag (`phase-1` .. `phase-4`).
Every requirement must map to a concrete verification method, saved output/screenshot, and honest result (`PASS` or `NOT MET` with reason).

| Phase | Tag | Proof File | Status |
|---|---|---|---|
| CP0 (Hello 3D + Headless) | *(untagged setup)* | [cp0-hello.md](cp0-hello.md) | PASS |
| Phase 1 | `phase-1` | [phase-1.md](phase-1.md) | PASS |
| Phase 2 | `phase-2` | [phase-2.md](phase-2.md) | PASS |
| Phase 3 | `phase-3` | [phase-3.md](phase-3.md) | PASS |
| Phase 4 | `phase-4` / `v1.0.0` | [phase-4.md](phase-4.md) | PASS |
